# Customer Churn Prediction

This project predicts customer churn using historical behavior and transaction data.

## 📘 Overview
- **Goal**: Predict whether a customer will leave (churn) or stay.
- **Tools Used**: Python (Pandas, Scikit-learn), SQL
- **Outcome**: Identify high-risk customers and suggest retention strategies.

## 🚀 Features
1. Data preprocessing and feature engineering
2. Model training with Logistic Regression and Random Forest
3. Evaluation using Accuracy, Precision, Recall, and ROC-AUC
4. SQL queries for data extraction and transformation
5. Business insights and churn reduction recommendations

## 🧠 Steps to Run
```bash
# Clone the repository
git clone https://github.com/yourusername/Customer-Churn-Prediction.git
cd Customer-Churn-Prediction

# Install dependencies
pip install -r requirements.txt

# Run the notebook
jupyter notebook churn_prediction.ipynb
```

## 🧩 Project Structure
```
├── README.md
├── requirements.txt
├── churn_prediction.ipynb
├── data.sql
├── churn_model.py
├── report.md
```

## 📊 Results
- Best Model: Random Forest Classifier
- Accuracy: ~87%
- Top Features: Tenure, MonthlyCharges, ContractType

## 💡 Business Insights
1. Customers with month-to-month contracts churn more often.
2. Discounts for long-term contracts can improve retention.
3. High monthly charges correlate with higher churn rates.
4. Senior citizens and single-line users have higher churn tendencies.

---
👨‍💻 Developed by [Your Name]
