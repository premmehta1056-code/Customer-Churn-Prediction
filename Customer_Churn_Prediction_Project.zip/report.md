# Customer Churn Prediction Report

## 1. Objective
To predict customer churn and suggest actionable strategies for customer retention.

## 2. Data Summary
- Customer demographic, service, and billing data.
- Target variable: **Churn** (Yes/No).

## 3. Model Used
- Logistic Regression
- Random Forest Classifier

## 4. Key Findings
1. Month-to-month contracts lead to higher churn.
2. High monthly charges increase churn probability.
3. Long-tenure customers are more loyal.

## 5. Strategies to Reduce Churn
- Offer discounts for long-term contracts.
- Improve customer support for high-risk groups.
- Personalized offers based on usage and history.
